/**
 * append-only 会话日志层（F2 / N1 —— POC-3 断言框架的产品化）
 *
 * 设计口径：
 *  - 哈希链（SHA-256）为 CAR 自研增强（dsh 无此物，源码级核实）——合规卖点落地
 *  - 「Model-visible means logged」：断言口径 = 请求时快照 === 日志前缀 [0, atSeq) 投影
 *  - 1.6-S1（D-23）：投影对同 id toolResult 收敛 last-wins——事件面/审计面不动，模型可见流去冗余
 *  - append-only：本层仅暴露 append/verifyChain/deriveMessages/assertModelVisibleLogged
 */
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { decodeLogBuffer, splitJsonlLines } from './format.ts'

export type EventKind = 'user' | 'assistant' | 'toolCall' | 'toolResult' | 'turnEnd' | 'goalUpdate' | 'hostRaw' | 'fork' | 'system' | 'usage' | 'compact' | 'routing' | 'memory' // M3-S11 加法扩展：多宿主归一化降级通道（pattern 未命中留痕，零静默）；M5-DEC4 加法扩展：跨宿主 fork 标记事件；1.4-S2 加法扩展：system prompt 落链（§3.5.5：新模型可见输入 = 新事件类型）；1.11-S2 加法扩展：usage 计量事实（D-33，actor='runtime'、model_visible=0 不进模型消息流，deriveMessages 不投影）；六值 TurnEndReason 不变；1.14-S2 加法扩展（K-MP-2 / D-40）：历史压缩事件（actor='runtime'，append-only 只追加——payload={summary, compactedUpTo, ...}，投影按 compactedUpTo 前缀折叠为摘要，原事件链不改写）；1.14-S4 加法扩展（K-POOL-1 / D-42）：模型池路由决策（actor='runtime'，payload.type='decide'，selected/reason/retries/attempts——禁静默换模型；model_visible=0 不进模型消息流，deriveMessages 不投影——同 usage 纪律）；1.15-S1 加法扩展（K-MEM-1 / D-46）：白盒记忆操作事件（actor='user' 宿主代理用户操作，turnId='memory' 会话级标识同 'compaction' 先例，payload.type='write'|'edit'|'delete'|'rollback'——审计链同源差异化面，链即版本库〔rollback 恢复数据源=链上 payload.before/after 全文〕；model_visible=0 不进模型消息流——记忆注入走宿主装配层 system ctx 行，deriveMessages 不投影）；
export type Actor = 'user' | 'model' | 'plugin' | 'runtime'
export interface SessionEvent {
  seq: number
  ts: number
  actor: Actor
  kind: EventKind
  turnId: string
  payload: unknown
  meta?: Record<string, unknown>
  prevHash: string
  hash: string
}

const sha = (s: string) => createHash('sha256').update(s).digest('hex')
const canonical = (e: Omit<SessionEvent, 'hash'>) =>
  sha(JSON.stringify({ seq: e.seq, ts: e.ts, actor: e.actor, kind: e.kind, turnId: e.turnId, payload: e.payload, meta: e.meta ?? null, prevHash: e.prevHash }))

export interface ModelSnapshot {
  /** 快照对应日志前缀边界（事件数），断言时逐字节比对前缀投影 */
  atSeq: number
  /**
   * 1.15-S2（K-STEER-1 / D-47）：快照时宿主声明的活跃 turn——提供时快照投影 = 边界内
   * 「活跃 turn 起点之后落链的他 turn user 事件被过滤」口径（与请求投影同构，N1 逐字节
   * 自洽）；缺席 = 全量前缀投影（1.14.1 形态，行为零变化）。
   */
  activeTurnId?: string
  request: unknown[]
}

export class SessionLog {
  readonly sessionId: string
  events: readonly SessionEvent[] = []
  #tail = 'GENESIS'
  #snapshots: ModelSnapshot[] = []
  #sink: ((line: string) => void) | null = null

  constructor(sessionId = 'S-' + Date.now().toString(36)) {
    this.sessionId = sessionId
  }

  /**
   * 挂载落盘 sink（§3.2.M7.5 Step 1-2「先落日志后放行」）：append 时同步写盘，
   * sink 成功后才入内存；sink throw = 写失败 fail-fast（事件不入内存、不推进链尾，
   * 调用方当前 turn 以 error 收口——内存与盘面永不失配）。
   */
  attachSink(sink: (line: string) => void): void {
    this.#sink = sink
  }

  /** 唯一写入路径（append-only；无 update/delete API） */
  append(actor: Actor, kind: EventKind, turnId: string, payload: unknown, meta?: Record<string, unknown>): SessionEvent {
    const e: Omit<SessionEvent, 'hash'> = {
      seq: this.events.length, ts: Date.now(), actor, kind, turnId, payload, meta, prevHash: this.#tail,
    }
    const full: SessionEvent = { ...e, hash: canonical(e) }
    if (this.#sink) this.#sink(JSON.stringify(full))
    this.events = [...this.events, full]
    this.#tail = full.hash
    return full
  }

  /** 模型请求发起时调用（agent-loop 集成点）：登记「请求时快照」；opts.activeTurnId 见 ModelSnapshot 注记 */
  snapshotModelRequest(opts?: { activeTurnId?: string }): ModelSnapshot {
    const filter = opts?.activeTurnId ? { activeTurnId: opts.activeTurnId } : undefined
    const snap: ModelSnapshot = {
      atSeq: this.events.length,
      // 1.15-S2：口径必须随快照落盘——assert 重算时以同口径投影逐字节比对（漏存 = 口径丢失 → N1 假红）
      ...(filter ? { activeTurnId: filter.activeTurnId } : {}),
      request: structuredClone(this.deriveMessages(this.events.length, filter)),
    }
    this.#snapshots.push(snap)
    return snap
  }

  /** 逐链校验；返回 null=完整，否则断链事件序号（审计导出前置，断链即中止） */
  verifyChain(): number | null {
    let prev = 'GENESIS'
    for (const e of this.events) {
      if (e.prevHash !== prev || e.hash !== canonical(e)) return e.seq
      prev = e.hash
    }
    return null
  }

  /**
   * 投影：从日志前缀重建模型可见消息流（不依赖模型运行时状态）。
   * 1.6-S1（D-23）同 id toolResult 收敛 last-wins：写类工具授权决策（runtime/toolResult）
   * 与执行结果（plugin/toolResult）成对落链（M4 既有语义冻结——审计全量留痕不动），
   * 模型可见流只保留最终结果（真实 provider 对重复 tool_call_id/tool_use_id 拒绝或未定义，
   * 1.4 观察项经真实适配器落地升级为缺陷面）。id 缺席不收敛（hostRaw/无 id 载荷形态不变，
   * golden ④ 投影语义兼容）；授权拒绝单条即唯一结果原样保留。适配器侧零改动（消费已收敛上游）。
   * 1.14-S2（K-MP-2 / D-40）：compact 事件投影——scoped 内最后一条 compact 生效（last-wins），
   * 其 compactedUpTo 前缀折叠为单条 system 摘要（事件原文不改写，仅投影层折叠）；compact 之前的
   * 请求快照（atSeq ≤ compact.seq）不含 compact 事件 → 投影仍为全量形态（N1 不变量自洽——
   * 「请求时发出 = 日志前缀投影」逐快照成立）；无 compact 事件的日志投影与 1.13 逐字节一致。
   * 1.15-S2（K-STEER-1 / D-47）投影隔离：opts.activeTurnId 提供时，跳过「turn 进行中落链的
   * 他 turn user 事件」（特征 = kind='user' 且 seq > 活跃 turn 首事件 seq 且 turnId ≠ 活跃
   * turnId——引导排队事件的链上形态）——**引导 ≠ 注入当前 turn 上下文**；不采用 turn 开始
   * 快照（快照会误杀 turn 内落的 toolResult——agent loop 依赖实时投影），过滤口径精确匹配
   * 「turn 外增量不进、turn 内增量照进」；无引导事件时过滤零命中，投影与 1.14.1 逐字节一致
   * （兼容线）。缺省（无 opts）= 1.14.1 行为零变化。
   */
  deriveMessages(upTo?: number, opts?: { activeTurnId?: string }): Array<{ role: string; [k: string]: unknown }> {
    const scoped = upTo !== undefined ? this.events.slice(0, upTo) : this.events
    let compactEvent: SessionEvent | undefined
    for (const e of scoped) { if (e.kind === 'compact') compactEvent = e } // last-wins
    let compactedUpTo: number | undefined
    if (compactEvent) {
      const cp = (compactEvent.payload ?? {}) as { summary?: unknown; compactedUpTo?: unknown }
      if (typeof cp.summary !== 'string' || !cp.summary.length || typeof cp.compactedUpTo !== 'number') {
        throw new Error(`CAR-E-COMPACT-PAYLOAD: compact 事件 seq=${compactEvent.seq} 缺有效 summary/compactedUpTo（投影拒绝——fail-visible）`)
      }
      compactedUpTo = cp.compactedUpTo // 折叠边界 = payload 声明的前缀边界（非 compact 事件自身 seq）
    }
    // 1.15-S2 投影隔离（D-47）：活跃 turn 首事件 seq 之后落链的他 turn user 事件 → 跳过
    let steerSkip: ((e: SessionEvent) => boolean) | undefined
    if (opts?.activeTurnId) {
      let turnStartSeq = -1
      for (const e of scoped) {
        if (e.turnId === opts.activeTurnId) { turnStartSeq = e.seq; break }
      }
      if (turnStartSeq >= 0) {
        steerSkip = (e: SessionEvent) => e.kind === 'user' && e.turnId !== opts.activeTurnId && e.seq > turnStartSeq
      } // 活跃 turn 无链上事件（异常形态）→ 不过滤（fail-safe 退化为 1.14.1 全量投影）
    }
    const projected = compactedUpTo !== undefined ? scoped.filter(e => e.seq >= compactedUpTo! && !(steerSkip?.(e) ?? false)) : scoped.filter(e => !(steerSkip?.(e) ?? false))
    const lastSeqById = new Map<string, number>()
    for (const e of projected) {
      if (e.kind !== 'toolResult') continue
      const id = (e.payload as { id?: unknown } | null)?.id
      if (typeof id === 'string') lastSeqById.set(id, e.seq)
    }
    const out: Array<{ role: string; [k: string]: unknown }> = []
    if (compactEvent) out.push({ role: 'system', content: ((compactEvent.payload as { summary: string }).summary) })
    for (const e of projected) {
      if (e.kind === 'system') out.push({ role: 'system', content: e.payload })
      else if (e.kind === 'user') out.push({ role: 'user', content: e.payload })
      else if (e.kind === 'assistant') out.push({ role: 'assistant', content: e.payload })
      else if (e.kind === 'toolCall') out.push({ role: 'assistant', toolCall: e.payload })
      else if (e.kind === 'toolResult') {
        const id = (e.payload as { id?: unknown } | null)?.id
        if (typeof id === 'string' && lastSeqById.get(id) !== e.seq) continue // D-23：后续有同 id 最终结果，本条为授权中间记录
        out.push({ role: 'toolResult', content: e.payload })
      }
    }
    return out
  }

  /** N1 不变量断言（CI 门禁雏形）：全部快照必须与当前日志前缀投影逐字节一致（快照口径含 1.15-S2 activeTurnId 过滤） */
  assertModelVisibleLogged(): { ok: boolean; failedAt?: number } {
    for (const s of this.#snapshots) {
      const filter = s.activeTurnId ? { activeTurnId: s.activeTurnId } : undefined
      if (JSON.stringify(s.request) !== JSON.stringify(this.deriveMessages(s.atSeq, filter))) {
        return { ok: false, failedAt: s.atSeq }
      }
    }
    return { ok: true }
  }

  /** 只读统计（供监控/测试） */
  stats() {
    return { events: this.events.length, snapshots: this.#snapshots.length, tailHash: this.#tail }
  }

  /** 从已校验事件数组重建（恢复 #tail，续跑 append 不断链——跨宿主 fork/resume 装载入口） */
  static fromEvents(sessionId: string, events: readonly SessionEvent[]): SessionLog {
    const log = new SessionLog(sessionId)
    ;(log.events as SessionEvent[]) = [...events]
    const last = events[events.length - 1]
    if (last) log.#tail = last.hash
    return log
  }

  /** 导出取证数据（MVP 基础导出：JSONL 全量 + 审计元数据；F15 完整包为 M2） */
  exportJSONL(): string {
    return this.events.map(e => JSON.stringify(e)).join('\n') + '\n'
  }
}

/** 文件路径 → sessionId 推导：`session-<id>.jsonl[.zstd]` 去前缀后缀；`events.jsonl` 取父目录名（审计定位口径） */
export function deriveSessionId(file: string): string {
  const base = file.replace(/.*[/\\]/, '')
  let id = base.replace(/\.jsonl\.zstd$/, '').replace(/\.jsonl$/, '')
  if (id === 'events') {
    const dir = file.replace(/[\\/][^/\\]*$/, '')
    const name = dir.replace(/.*[/\\]/, '')
    if (name && name !== dir) id = name // 有父目录才取父目录名，否则保留 'events'
  } else if (id.startsWith('session-')) id = id.slice('session-'.length)
  return id
}

/**
 * 从 JSONL 文件装载（审计回放/跨机迁移入口）。格式层语义见 format.ts：
 * 撕裂尾显式报告（丢弃崩溃半行，不静默）；完整行解析失败 CAR-E-FORMAT 拒绝装载；
 * 断链 = brokenAt 返回（由调用方决定中止口径）。zstd 文件按 magic 嗅探直读。
 */
export function loadSessionLog(file: string): {
  log: SessionLog
  brokenAt: number | null
  encoding: 'plain' | 'zstd'
  tornTail: boolean
  tornTailBytes: number
} {
  const { text, encoding } = decodeLogBuffer(readFileSync(file))
  const { lines, tornTail, tornTailBytes } = splitJsonlLines(text)
  const events = lines.map((l, i) => {
    try { return JSON.parse(l) as SessionEvent }
    catch (e) { throw new Error(`CAR-E-FORMAT: ${file} 第 ${i + 1} 行非法 JSON——拒绝装载带病日志（${(e as Error).message}）`) }
  })
  const log = SessionLog.fromEvents(deriveSessionId(file), events)
  return { log, brokenAt: log.verifyChain(), encoding, tornTail, tornTailBytes }
}

export { sha as sha256Hex }
