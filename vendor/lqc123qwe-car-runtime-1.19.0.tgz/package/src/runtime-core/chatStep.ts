/**
 * M8 · SQ-07 模型接入集成（chat → 流式消费 → assistant 落 M7 → ModelStep 交 M4 状态机）
 *
 * 时序对齐（§3.2.M8.4 SQ-07 逐行）：
 *  1. 请求前断言：assertModelVisibleLogged（配合 M7，N1 不变量前置）；
 *  2. 请求消息 = log.deriveMessages() 投影——Model-visible means logged 由构造保证
 *     （本层不引入任何未落链的模型可见输入：新增可见输入必须新增事件类型，§3.5.5 红线；
 *     system prompt 组装属 M4/M2 职责，v1 不在本层旁路）；
 *  3. 凭据解析在适配器内（resolve→reveal，A080001 在首块前抛出 → runTurn catch → turn error，
 *     用户文案引导 car doctor）；
 *  4. 流式消费：delta 过 StreamRedactor（跨 chunk 命中不泄漏）+ toolCallDelta 聚合
 *     （半截 JSON 不解析——ADR-001 同纪律，length 时只交 truncatedTools）；
 *  5. assistant 文本事件落 M7（脱敏后 + secretsRedacted 计数留痕 meta）；
 *  6. finishReason 不可变透传为 ModelStep.stopReason（error/aborted → 'error'，BD-04 收口
 *     由 runTurn 落 turnEnd）；工具调用事件由 runTurn executeBatch 落（本层不重复）；
 *  7. 1.11-S2（D-33 / 计量设计 §3.3）：流尾 usage chunk → 'runtime'/'usage' 请求级事实落链
 *     （缺失 = provider 未回/流中断/畸形，禁补造；actor='runtime'、model_visible=0 不进模型
 *     消息流）——turn 级聚合在 stop.ts 收口单点，本层不做跨请求状态。
 */
import type { SessionLog } from '../session/log.ts'
import { TurnAborted, type ModelStep, type ToolCall } from '../loop/stop.ts'
import type { RuntimeCore } from './llm.ts'
import type { LlmUsage, ToolDefinition } from './types.ts'
import { StreamRedactor } from './redaction.ts'
import { scanSecrets } from '../security/secrets.ts'
import { providerUnreachable } from './errors.ts'

export interface ChatStepOptions {
  core: RuntimeCore
  log: SessionLog
  turnId: string
  /** 模型名（provider 侧路由） */
  model: string
  /** 工具声明面（ToolDefinition 含 declaredSideEffect；不出站权限面仅 schema） */
  tools: ToolDefinition[]
  maxTokens?: number
  adapterId?: string
  /** 1.4-S4（D-19）：turn 取消信号——chunk 间隙与流结束后（finish 检查前）检查，命中抛 TurnAborted */
  signal?: { aborted: boolean }
  /**
   * 1.14.1（K-MP-1 消费面 / D-39）：思考参数透传——chatStep 是宿主 model 回调的唯一路径，
   * 本形参补齐后 reasoning 才经 chatStep 可达（off / 缺席 = 不下发该字段，字节面零痕迹）；
   * 模型元数据思考档位判断在宿主侧（models:meta），内核防线 = 未知档位 fail-visible。
   */
  reasoning?: { effort: 'off' | 'low' | 'medium' | 'high' }
  /**
   * 1.19.0（D-S2-1 渲染提示面）：流式增量回调——宿主实时上屏数据源（发送后不空等的
   * 流式交互）。语义红线：
   *  - textDelta = StreamRedactor.push 的已遮蔽放行（跨 chunk 遮蔽驻留期 UI 略滞后——
   *    粒度换正确性），流尾 flush 残段同样回调；全部 textDelta 之和 + flush 尾巴
   *    ≡ 落链 assistant 全文（收敛一致，屏幕无第二事实源）；
   *  - toolName = 工具名首次可知时机（args 仍在流式聚合——半截 JSON 不解析，ADR-001
   *    同纪律）；同请求同名只回调一次；
   *  - 纯渲染提示：不落链、不持久、不影响 ModelStep 与 N1（事实本体仍以落盘行为准，
   *    assistant 事件到达前 UI 呈现的增量属临时态）；缺省（undefined）= 零行为变化。
   */
  onDelta?: (d: { textDelta?: string; toolName?: string }) => void
}

/** ModelStep 加法扩展：脱敏计数留痕（S15 secretsRedacted 同名口径） */
export type ChatStepResult = ModelStep & { secretsRedacted: number }

export async function chatStep(opts: ChatStepOptions): Promise<ChatStepResult> {
  const { core, log, turnId, model, tools, maxTokens, adapterId } = opts

  // 1. 请求前断言（SQ-07 #2）：N1 失守 = 带病请求，显式拒绝
  const asserted = log.assertModelVisibleLogged()
  if (!asserted.ok) {
    throw new Error(`CAR-E-N1: 模型请求前快照与日志投影失配 @ atSeq=${asserted.failedAt}（Model-visible means logged 违规）`)
  }

  // 2. 请求消息 = 投影（角色系统：user/assistant/toolResult 与 LlmRequest 对齐）；
  //    toolCall 事件投影形态为 { role:'assistant', toolCall }（log.ts 口径）——此处归一化为
  //    content {toolCall} 载荷（适配器历史回路映射的唯一消费源）。
  //    1.5-BUG-1：此前仅透传 m.content，toolCall 属性被丢弃——工具调用历史在后续请求
  //    静默消失（真实 provider 对无 tool_calls 前驱的 tool 消息直接 400）；anthropic E2E
  //    生产调用点核查（1.5-GO-5）暴露，openai-compat 同样受益。
  //    1.15-S2（K-STEER-1 / D-47）：投影带活跃 turn 口径——turn 进行中落链的他 turn user
  //    事件（引导排队）不进当前 turn 请求（引导 ≠ 注入当前 turn 上下文红线）；无引导事件
  //    时与 1.14.1 投影逐字节一致（兼容线）。
  const messages = log.deriveMessages(undefined, { activeTurnId: turnId }).map(m => ({
    role: m.role as 'system' | 'user' | 'assistant' | 'toolResult',
    content: (m as unknown as { toolCall?: unknown }).toolCall !== undefined
      ? { toolCall: (m as unknown as { toolCall: unknown }).toolCall }
      : m.content,
  }))

  // 4. 流式消费（3. 凭据解析在适配器首块前，A080001 由此传播）
  const redactor = new StreamRedactor()
  let text = ''
  const calls = new Map<number, { id?: string; name?: string; argsBuf: string }>()
  let stopReason: ModelStep['stopReason'] | undefined
  let errorDetail: string | undefined
  let usage: LlmUsage | undefined

  const stream = core.chat({
    model,
    messages,
    tools,
    ...(maxTokens != null ? { maxTokens } : {}),
    ...(adapterId ? { adapterId } : {}),
    // 1.14.1（K-MP-1 消费面）：reasoning 透传（off/缺席 = 不下发）
    ...(opts.reasoning ? { reasoning: opts.reasoning } : {}),
    ...(opts.signal ? { signal: opts.signal } : {}),
    ...(opts.log.sessionId ? { metadata: { sessionId: opts.log.sessionId, turnId, traceId: `${opts.log.sessionId}:${turnId}` } } : {}),
  })
  for await (const chunk of stream) {
    // 1.4-S4（D-19）：chunk 间隙取消——此刻 assistant 尚未落链（流完才 append），无半截消息
    if (opts.signal?.aborted) throw new TurnAborted()
    if (chunk.delta !== undefined) {
      const masked = redactor.push(chunk.delta)
      text += masked
      if (masked && opts.onDelta) opts.onDelta({ textDelta: masked })
    }
    if (chunk.toolCallDelta) {
      const idx = chunk.toolCallDelta.index ?? 0
      const cur = calls.get(idx) ?? { argsBuf: '' }
      if (chunk.toolCallDelta.id) cur.id = chunk.toolCallDelta.id
      if (chunk.toolCallDelta.name) {
        cur.name = chunk.toolCallDelta.name
        // 1.19.0：工具名首次可知即回调（args 半截 JSON 不解析——ADR-001）；同名一次
        if (opts.onDelta) opts.onDelta({ toolName: cur.name })
      }
      if (chunk.toolCallDelta.argumentsDelta) cur.argsBuf += chunk.toolCallDelta.argumentsDelta
      calls.set(idx, cur)
    }
    if (chunk.error) errorDetail = chunk.error.message
    if (chunk.usage) usage = chunk.usage // D-33：附着于最后一个 chunk——后到覆盖
    if (chunk.finishReason !== undefined) stopReason = chunk.finishReason === 'aborted' ? 'error' : chunk.finishReason
  }
  // 1.4-S4（D-19）：finish 检查前先查取消（适配器取消路径静默收口无 finishReason——
  // 必须先于此处的契约兜底，否则取消被误判为适配器违规）
  if (opts.signal?.aborted) throw new TurnAborted()
  if (stopReason === undefined) {
    // 适配器层已保证首 finishReason（AL-05）；防御性兜底显式化
    throw new Error('CAR-E-LLM-FINISH: 流结束无 finishReason（适配器契约违规）')
  }
  // 1.19.0：flush 残段先回调后并入 text——textDelta 之和 + 尾巴 ≡ 落链 assistant 全文
  const tail = redactor.flush()
  if (tail && opts.onDelta) opts.onDelta({ textDelta: tail })
  text += tail

  // 1.11-S2（D-33 / 计量设计 §3.3）：请求级 usage 事实落链（拿到 usage 的最后一个 chunk 即请求
  // 收尾；撞限/异常 turn 照常落——截断前已完成请求的 usage 事实不吞）。缺失 = provider 未回，
  // 禁补造；actor='runtime'、不进模型消息流（deriveMessages 不投影 usage，§2.5 红线）
  if (usage) {
    log.append('runtime', 'usage', turnId, {
      model: usage.model,
      adapterId: usage.adapterId,
      input: usage.inputTokens,
      output: usage.outputTokens,
      cacheRead: usage.cacheReadTokens,
      cacheCreation: usage.cacheCreationTokens,
      // 1.14-S3（K-MP-2b / D-41）：分段事实随事件落链——无分段 = 不带键（禁估算）
      ...(usage.segments ? { segments: usage.segments } : {}),
      providerRaw: usage.providerRaw,
    })
  }

  // 5. assistant 文本落 M7（脱敏后 + 计数留痕；空文本不产事件）
  //    flush 后兜底复扫只计数不复写：流式遮蔽已生效，>0 即流式边界逃逸的审计信号
  let secretsRedacted = 0
  if (text.length) {
    secretsRedacted = scanSecrets(text).hits.length
    log.append('model', 'assistant', turnId, text, { secretsRedacted })
  }

  // 6. finishReason → ModelStep（不可变透传；length 不解析 args——ADR-001 解析前收口）
  if (stopReason === 'length') {
    const truncated = [...calls.values()].filter(c => c.id || c.name).map(c => ({ id: c.id ?? `tc-${c.name ?? 'unknown'}`, tool: c.name ?? 'unknown' }))
    return { stopReason: 'length', ...(text ? { text } : {}), truncatedTools: truncated, secretsRedacted }
  }
  if (stopReason === 'toolUse') {
    const toolCalls: ToolCall[] = []
    for (const [idx, c] of [...calls.entries()].sort((a, b) => a[0] - b[0])) {
      if (!c.name) continue
      let args: Record<string, unknown>
      try { args = c.argsBuf ? JSON.parse(c.argsBuf) as Record<string, unknown> : {} } catch {
        // toolUse 声明下 args 非法 JSON = 协议违规显式化（非 length 场景无 truncatedTools 口径）
        throw new Error(`CAR-E-LLM-PROTO: 工具调用 ${c.name} 参数非法 JSON（finishReason=${stopReason}，${errorDetail ?? '无附加错误'}）`)
      }
      toolCalls.push({ id: c.id ?? `tc-${idx}-${c.name}`, tool: c.name, args })
    }
    return { stopReason: 'toolUse', ...(text ? { text } : {}), ...(toolCalls.length ? { toolCalls } : {}), secretsRedacted }
  }
  // error（含 aborted 映射）：以 B080001 抛出 → runTurn catch → turnEnd error 携带 detail（BD-04 收口）
  if (stopReason === 'error') {
    throw providerUnreachable(errorDetail ?? 'provider 返回 error 终止（无附加说明）')
  }
  return { stopReason: 'stop', ...(text ? { text } : {}), secretsRedacted }
}
