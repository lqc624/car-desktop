/**
 * M8 · LLM 适配面（chat / registerLlmAdapter ——《系统设计》§3.2.M8.2 模型与适配行 / SQ-07 / O-11）
 *
 * 口径：
 *  - 适配器为 ACL（C-02）：统一 LlmAdapter 签名消解 Provider 差异；注册经 ctx.effect 可逆
 *    （disposeRuntime 回卷后可重注册——注册即逆变换，POC-2 红线同源）；重复 id 显式报错禁静默覆盖；
 *  - finishReason 不可变透传（ADR-001 / SR-17）：SDK 边界流包装做防御性断言——首个
 *    finishReason 定格，冲突 = 适配器契约违规显式抛错（改写/吞没均禁止，缺失触发 AL-05 口径）；
 *  - 重试基线（§3.5.4）：仅网络错误/429/5xx、≤2 次、指数退避 1s/2s；**首块前失败才可重试**
 *    （已消费的 chunk 不可重放——重试不产生额外副作用）；重试耗尽 = CarM8Error B080001
 *    （BD-04 error 收口由消费方 runTurn 落 turnEnd）；流中途失败 = finishReason 'error' chunk；
 *  - 超时基线：总 120s / 首字节 30s（均可注入缩短供测试）；TLS 强制（https-only，D-12a
 *    loopback 豁免共用 assertTlsOrLoopback）；重试/超时/取消引擎单点共用（1.5-S1 streamSsePost
 *    ——openai-compat / anthropic 语义不漂移，parse 为唯一 provider 差异点）；
 *  - declaredSideEffect 不出站（权限面只进权限门，不进模型请求体）；
 *  - 1.5-S1（D-20）：内置 anthropic 适配器（Messages API 流式；max_tokens 必填缺省 4096；
 *    system 顶层化；凭据 provider='anthropic'）。
 *  - 1.8-BUG-1：出站缺省通道 node:http(s)（nodeHttpSseFetch——1.4-BUG-2 口径延伸到 LLM 面）：
 *    全局 fetch/undici socket 在 win32 进程退出时触发 libuv 断言崩溃（UV_HANDLE_CLOSING,
 *    0xC0000409）——car run 真路径 ≥3 次模型请求 + PTC worker/MCP 子进程并存即确定性复现
 *    （1.4 彼时仅修遥测出站，LLM 出站同为 undici 默认——潜伏至 1.8 E2E 三请求形态暴露）；
 *    流式契约 body = AsyncIterable<Uint8Array> 不变；测试注入缝 fetchImpl 保留。
 *  - 1.11-S1（D-33 / 计量设计 §3.2）：usage 采集——openai 请求体加 stream_options.include_usage
 *    （默认开启，第三方网关不兼容时回退 = baseUrl 白名单，登记可回退项；缺失走缺失口径禁估算），
 *    解析「先摘 evt.usage 再判 choice」（空 choices 尾包不再被吞）；anthropic message_start（input 侧）
 *    + message_delta（output 侧）两包合并（message_delta 缺席 = output 不完整，整条不落）；
 *    归一口径 §1.1（openai 减法 / anthropic 透传 + cache_creation），畸形/缺失整条不落（禁补造）。
 *  - 1.14-S1（K-MP-1 / D-39）：思考参数透传——LlmRequest.reasoning.effort 按家族映射：
 *    openai-compat = `reasoning_effort`；anthropic = `thinking:{type:'enabled',budget_tokens}`
 *    （ANTHROPIC_THINKING_BUDGET 表）；**off / 缺席 = 字节面不下发**；未知 effort 值显式报错
 *    （CAR-E-LLM-REASONING，fail-visible 禁静默忽略——宿主越型传入防线）；anthropic 侧
 *    budget ≥ max_tokens 违反 API 约束 → 显式报错提示调高（禁静默改写 max_tokens）。
 */
import { CarM8Error, providerUnreachable } from './errors.ts'
import { CredentialService } from './credentials.ts'
import type { Disposable, LlmAdapter, LlmChunk, LlmRequest, LlmUsage, ToolCallDelta } from './types.ts'
import type { PluginContext } from '../kernel/context.ts'
import { request as httpRequest } from 'node:http'
import { request as httpsRequest } from 'node:https'

// ==================== 适配器注册表（registerLlmAdapter） ====================

export class AdapterRegistry {
  #adapters = new Map<string, LlmAdapter>()
  #defaultId: string | null = null

  /** 注册（幂等语义：同 id 重复注册显式报错——冲突链定位风格） */
  register(adapter: LlmAdapter, opts: { default?: boolean } = {}): Disposable {
    if (this.#adapters.has(adapter.id)) {
      throw new Error(`CAR-E-LLM-DUP: LLM adapter "${adapter.id}" already registered (duplicate registration is blocked)`)
    }
    this.#adapters.set(adapter.id, adapter)
    if (opts.default || this.#defaultId === null) this.#defaultId = adapter.id
    let disposed = false
    return {
      dispose: () => {
        if (disposed) return // 幂等回卷（二次 dispose 静默收敛，登记口径）
        disposed = true
        this.#adapters.delete(adapter.id)
        if (this.#defaultId === adapter.id) this.#defaultId = this.#adapters.keys().next().value ?? null
      },
    }
  }

  /** 解析：显式 id > 默认适配器；无可用适配器显式报错（禁静默降级） */
  get(id?: string): LlmAdapter {
    const target = id ?? this.#defaultId
    if (!target || !this.#adapters.has(target)) {
      const available = [...this.#adapters.keys()].join(', ') || '无'
      throw new Error(`CAR-E-LLM-NOADAPTER: LLM adapter "${target ?? '<default>'}" not registered（在册：${available}）`)
    }
    return this.#adapters.get(target)!
  }

  list(): Array<{ id: string; isDefault: boolean }> {
    return [...this.#adapters.keys()].map(id => ({ id, isDefault: id === this.#defaultId }))
  }
}

// ==================== 1.14-S1（K-MP-1 / D-39）思考参数映射 ====================

/** 归一思考档位：缺席/off → undefined（不下发）；low/medium/high 原样；未知值 fail-visible（宿主越型传入防线） */
export function normalizeReasoningEffort(effort: unknown): 'off' | 'low' | 'medium' | 'high' | undefined {
  if (effort === undefined || effort === null) return undefined
  if (effort === 'off' || effort === 'low' || effort === 'medium' || effort === 'high') return effort
  throw new Error(`CAR-E-LLM-REASONING: 未知思考档位 "${String(effort)}"（合法：off/low/medium/high；off/缺席 = 不下发）`)
}

/** anthropic effort → thinking.budget_tokens 映射（D-39 登记表）；off/缺席不下发 */
const ANTHROPIC_THINKING_BUDGET: Record<'low' | 'medium' | 'high', number> = {
  low: 2048,
  medium: 8192,
  high: 16384,
}

// ==================== finishReason 不可变守卫（SDK 边界） ====================

/** 首个 finishReason 定格；适配器后续给出不同值 = 契约违规显式抛错（不改写不吞没） */
export async function* withFinishReasonGuard(stream: AsyncIterable<LlmChunk>): AsyncIterable<LlmChunk> {
  let settled: LlmChunk['finishReason'] | undefined
  for await (const chunk of stream) {
    if (chunk.finishReason !== undefined) {
      if (settled === undefined) settled = chunk.finishReason
      else if (settled !== chunk.finishReason) {
        throw new Error(`CAR-E-LLM-FINISH: finishReason 已定格为 "${settled}"，适配器试图给出 "${chunk.finishReason}"（不可变透传契约违规）`)
      }
    }
    yield chunk
  }
}

// ==================== RuntimeCore（M8 SDK 面） ====================

export class RuntimeCore {
  readonly registry = new AdapterRegistry()
  readonly credentials: CredentialService
  #ctx: Pick<PluginContext, 'provide' | 'effect'> | null = null

  constructor(credentials: CredentialService = new CredentialService()) {
    this.credentials = credentials
  }

  /** 绑定插件作用域：服务注册 + 适配器注册进入 Effect 可逆通道（宿主传 Context——根作用域 effect 同纪律） */
  bindContext(ctx: Pick<PluginContext, 'provide' | 'effect'>): void {
    this.#ctx = ctx
    ctx.provide('runtime-core', this)
  }

  /** §3.2.M8.2：registerLlmAdapter(adapter): Disposable——Effect 可逆（卸载回卷后可重注册） */
  registerLlmAdapter(adapter: LlmAdapter, opts: { default?: boolean } = {}): Disposable {
    if (!this.#ctx) return this.registry.register(adapter, opts)
    let handle: Disposable | null = null
    this.#ctx.effect(() => {
      handle = this.registry.register(adapter, opts)
      return () => handle?.dispose()
    }, `llm-adapter:${adapter.id}`)
    return { dispose: () => handle?.dispose() }
  }

  /** §3.2.M8.2：chat(req): AsyncIterable<LlmChunk>——统一入口 + finishReason 守卫 */
  chat(req: LlmRequest): AsyncIterable<LlmChunk> {
    const adapter = this.registry.get(req.adapterId)
    return withFinishReasonGuard(adapter.chat(req))
  }
}

// ==================== 适配器共用基线（1.5-S1 抽取：D-12a TLS 门 + §3.5.4 流式引擎） ====================

/**
 * D-12a TLS 强制门（openai-compat / anthropic 共用，口径不变）：https 直接通过；
 * http 仅豁免 loopback——本地模型服务（Ollama 等）与本地 E2E；非回环地址维持 TLS 强制
 * （§3.2.M8.4）。豁免集显式列举，不扩大到局域网。
 */
export function assertTlsOrLoopback(baseUrl: string): void {
  if (baseUrl.startsWith('https://')) return
  let loopback = false
  try { const host = new URL(baseUrl).hostname.replace(/^\[|\]$/g, ''); loopback = host === '127.0.0.1' || host === 'localhost' || host === '::1' } catch { /* 解析失败 = 非法 URL，按非回环拒绝 */ }
  if (!loopback) {
    throw new Error(`CAR-E-LLM-TLS: baseUrl 必须 https（TLS 强制，§3.2.M8.4）；http 仅豁免 loopback（127.0.0.1/[::1]/localhost，D-12a）——远程明文部署请经 TLS 代理或自建适配器`)
  }
}

/** 流式 POST 请求规格（凭据解析在 buildRequest 内——A080001 首块前抛出，runTurn 可 error 收口） */
interface SsePostSpec {
  url: string
  buildRequest: () => Promise<{ method: 'POST'; headers: Record<string, string>; body: string }>
  fetchImpl: typeof fetch
  signal?: { aborted: boolean }
  timeoutMs: number
  firstByteMs: number
  retries: number
  backoffMs: number[]
  sleep: (ms: number) => Promise<void>
}

/** 1.8-BUG-1：node:http(s) 出站响应（streamSsePost 消费契约子集——ok/status/text()/body 流） */
interface SseFetchResponse { ok: boolean; status: number; text(): Promise<string>; body: AsyncIterable<Uint8Array> }

/**
 * 1.8-BUG-1：LLM 出站缺省通道——node:http(s) 流式 POST（1.4-BUG-2 同源口径：全局 fetch/undici
 * socket + win32 进程退出触发 libuv 断言崩溃 0xC0000409；详见面头注记）。流式契约：IncomingMessage
 * 本体即 AsyncIterable<Uint8Array>（Buffer 子类）；取消经 AbortSignal → req.destroy（流中途 destroy
 * = 迭代器抛错，streamSsePost D-19 路径收口）；传输层超时不设——§3.5.4 firstByte/overall 由调用方
 * AbortController 单点承载。
 */
const nodeHttpSseFetch = (url: string, init: { method?: string; headers?: Record<string, string>; body?: string; signal?: AbortSignal } = {}): Promise<SseFetchResponse> => new Promise((resolve, reject) => {
  try {
    const u = new URL(url)
    const mod = u.protocol === 'https:' ? httpsRequest : httpRequest
    const req = mod(u, { method: init.method ?? 'GET', headers: init.headers }, res => {
      const status = res.statusCode ?? 0
      // 1.15.2-BUG（桌面 S6 终验实证）：取消时 req.destroy(err) 会让**响应流** res 异步 emit
      // 'error'——此前无监听 → Node 抛 unhandled 'error' 事件 → 宿主进程直接退出（Electron
      // utilityProcess 无 uncaughtException 兜底时 = 句柄全失、引导队列被 resume 误标 interrupted）。
      // 迭代器侧已由 streamSsePost 的 catch 按 D-19 静默收口，此处监听仅防进程级未捕获异常
      res.on('error', () => { /* 取消/中断：由消费侧（streamSsePost catch）收口 */ })
      resolve({
        ok: status >= 200 && status < 300,
        status,
        text: () => new Promise<string>((res2, rej2) => {
          let s = ''
          res.on('data', c => { s += c.toString('utf-8') })
          res.on('end', () => res2(s))
          res.on('error', rej2)
        }),
        body: res,
      })
    })
    // 1.15.2-BUG（桌面 S6 终验 R-1 实证）：取消走 destroy() **不带 Error**——此前
    // `req.destroy(new Error('aborted'))` 在 Electron Node 24 宿主体内表现为进程级未捕获
    // 异常（响应流侧异步派发，无监听 → 宿主 utilityProcess 直接退出，句柄全失、引导队列被
    // resume 误标 interrupted）。取消语义已由 spec.signal / D-19 承载，无需错误对象；
    // res 侧 error 监听为双保险（中断时的取消性错误不再逃逸到进程级）。
    const onAbort = () => { try { req.destroy() } catch { /* 已完成 */ } }
    if (init.signal) {
      if (init.signal.aborted) onAbort()
      else init.signal.addEventListener('abort', onAbort, { once: true })
    }
    req.on('error', reject)
    req.end(init.body ?? null)
  } catch (e) { reject(e) }
})

/**
 * §3.5.4 流式 POST 引擎（openai-compat / anthropic 单点共用，1.5-S1 抽取——两适配器重试/
 * 超时/取消语义不漂移）：仅网络错误/429/5xx、≤2 次、指数退避 1s/2s；首块前失败才可重试
 * （已消费 chunk 不可重放）；重试耗尽 = CarM8Error B080001；外部取消 ≠ 失败（D-19：静默
 * 收口不 retry 不 error chunk）；流自然结束未携带 finishReason = AL-05 显式 error chunk。
 * `parse` 为唯一 provider 差异点（SSE 字节流 → LlmChunk）。
 */
async function* streamSsePost(spec: SsePostSpec, parse: (body: AsyncIterable<Uint8Array>) => AsyncIterable<LlmChunk>): AsyncIterable<LlmChunk> {
  const payload = await spec.buildRequest()
  for (let attempt = 0; ; attempt++) {
    // D-19：外部取消 ≠ 失败——attempt 前检查，静默收口（无 chunk、无 retry）
    if (spec.signal?.aborted) return
    const controller = new AbortController()
    const started = Date.now()
    let firstByteSeen = false
    const firstByteTimer = setTimeout(() => controller.abort(), spec.firstByteMs)
    const overallTimer = setTimeout(() => controller.abort(), spec.timeoutMs)
    try {
      const res = await spec.fetchImpl(spec.url, { ...payload, signal: controller.signal })
      if (res.status === 429 || res.status >= 500) throw new Retryable(`HTTP ${res.status}`)
      if (!res.ok) {
        const text = await res.text().catch(() => '')
        // 4xx 业务错不重试（§3.5.4）；错误信息不含凭据（凭据值不进错误路径）
        yield { finishReason: 'error', error: { code: 'B080001', message: `provider HTTP ${res.status}${text ? `：${text.slice(0, 200)}` : ''}` } }
        return
      }
      if (!res.body) throw new Retryable('响应无 body 流')
      let sawFinish = false
      for await (const chunk of parse(res.body)) {
        // D-19：chunk 间隙检查取消——abort 连接并静默收口（不产 error chunk，不违反
        // finishReason 不可变；上层 chatStep 以自身 signal 检查抛 TurnAborted）
        if (spec.signal?.aborted) { controller.abort(); return }
        if (!firstByteSeen) { firstByteSeen = true; clearTimeout(firstByteTimer) }
        if (chunk.finishReason !== undefined) sawFinish = true
        yield chunk
      }
      // 流自然结束但未给 finishReason = 异常终止（AL-05 口径：缺失显式化，禁吞没）；
      // 已携带 finishReason 的流原样收口——兜底不得追加（M8-BUG-1 口径延续）
      if (!sawFinish) {
        yield { finishReason: 'error', error: { code: 'B080001', message: '流结束未携带 finish_reason（AL-05）' } }
      }
      return
    } catch (e) {
      // D-19：外部取消（abort 连锁的 fetch 异常）≠ 失败——静默收口，不走 retry
      if (spec.signal?.aborted) return
      const beforeFirstByte = !firstByteSeen
      clearTimeout(firstByteTimer)
      // 首块前失败 = 网络错误/429/5xx/首字节超时（§3.5.4 重试条件全集）——未消费任何 chunk
      if (beforeFirstByte && attempt < spec.retries) {
        await spec.sleep(spec.backoffMs[Math.min(attempt, spec.backoffMs.length - 1)]!)
        continue
      }
      if (beforeFirstByte) {
        // 重试耗尽 → B080001（BD-04：消费方 runTurn 以 error 收口）
        throw providerUnreachable(`${(e as Error).name}: ${(e as Error).message}（尝试 ${attempt + 1}/${spec.retries + 1}，${Date.now() - started}ms）`)
      }
      // 流中途失败：已消费 chunk 不可重放 → error chunk 收口
      yield { finishReason: 'error', error: { code: 'B080001', message: `流中途失败：${(e as Error).message}` } }
      return
    } finally {
      clearTimeout(firstByteTimer)
      clearTimeout(overallTimer)
    }
  }
}

// ==================== 内置 openai-compat 适配器（流式 SSE） ====================

export interface OpenAICompatOptions {
  id?: string
  baseUrl: string
  /** 凭据服务与 provider 名（Bearer token 来源） */
  credentials?: CredentialService
  provider?: string
  /** 1.14-S4（K-POOL-1）：成员级凭据 env 变量名引用（modelPool keyEnv——resolve 精确候选；keychain 链保持在前） */
  credentialEnvVars?: string[]
  fetchImpl?: typeof fetch
  /** §3.5.4 基线：总 120s / 首字节 30s / 2 次退避 1s-2s（测试可注入缩短） */
  timeoutMs?: number
  firstByteMs?: number
  retries?: number
  backoffMs?: number[]
  /** 测试注入睡眠（退避可观测；缺省真实定时器） */
  sleep?: (ms: number) => Promise<void>
}

const FINISH_MAP: Record<string, LlmChunk['finishReason']> = {
  stop: 'stop',
  length: 'length',
  tool_calls: 'toolUse',
  function_call: 'toolUse',
  content_filter: 'aborted',
}

class Retryable extends Error {}

/**
 * 1.11-S1（D-33 / 计量设计 §1.1）：openai usage 归一——prompt_tokens 含 cached，inputTokens
 * 必须做减法（prompt − prompt_tokens_details.cached_tokens）；cache_creation 恒 0（无对应字段，
 * 登记不估算）。usage 对象缺席/畸形（两侧主字段任一非数值）= 整条不落（缺失口径，禁补造）。
 * 1.14-S3（K-MP-2b / D-41）：分段计量——completion_tokens_details.reasoning_tokens（思考输出
 * 细分，provider 真实事实）数值才采（segments.reasoningTokens）；details/字段缺席或非数值 =
 * segments 不带键（禁估算补造）。
 */
function normalizeOpenAIUsage(u: unknown, model: string, adapterId: string): LlmUsage | undefined {
  if (!u || typeof u !== 'object') return undefined
  const r = u as Record<string, unknown>
  if (typeof r.prompt_tokens !== 'number' || typeof r.completion_tokens !== 'number') return undefined
  const details = (r.prompt_tokens_details ?? null) as Record<string, unknown> | null
  const cached = details && typeof details.cached_tokens === 'number' ? details.cached_tokens : 0
  const compDetails = (r.completion_tokens_details ?? null) as Record<string, unknown> | null
  const reasoning = compDetails && typeof compDetails.reasoning_tokens === 'number' ? compDetails.reasoning_tokens : undefined
  return {
    inputTokens: r.prompt_tokens - cached,
    outputTokens: r.completion_tokens,
    cacheReadTokens: cached,
    cacheCreationTokens: 0,
    model,
    adapterId,
    providerRaw: u,
    ...(reasoning !== undefined ? { segments: { reasoningTokens: reasoning } } : {}),
  }
}

/** 明文 SSE → LlmChunk 流解析（增量容错：半行驻留到下一 chunk；1.11-S1：model/adapterId 供 usage 归一） */
async function* parseSseStream(body: AsyncIterable<Uint8Array>, model: string, adapterId: string): AsyncIterable<LlmChunk> {
  const decoder = new TextDecoder()
  let buf = ''
  for await (const bytes of body) {
    buf += decoder.decode(bytes, { stream: true })
    let nl: number
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).replace(/\r$/, '')
      buf = buf.slice(nl + 1)
      if (!line.startsWith('data:')) continue
      const data = line.slice(5).trim()
      if (data === '[DONE]') return
      if (!data) continue
      let evt: any
      try { evt = JSON.parse(data) } catch { continue } // 心跳/注释行容错（显式跳过非 JSON data）
      // 1.11-S1（D-33 / 计量设计 §3.2 必核行）：先摘 usage 再判 choice——stream_options.include_usage
      // 的尾包 choices 为空，下方 `if (!choice) continue` 原样会把它吞掉
      const usage = evt.usage !== undefined ? normalizeOpenAIUsage(evt.usage, model, adapterId) : undefined
      const choice = evt.choices?.[0]
      if (!choice) {
        // 独立 usage 尾包（官方形态：finish_reason chunk 之后、[DONE] 之前）——请求最后一个 chunk
        if (usage) yield { usage }
        continue
      }
      const delta = choice.delta ?? {}
      const raw = choice.finish_reason
      const finish: LlmChunk['finishReason'] | undefined = raw == null ? undefined : (() => {
        const mapped = FINISH_MAP[String(raw)]
        return mapped
          ? mapped
          : 'error' // 未映射信号 fail-visible（禁静默改写），raw 附在 error.message
      })()
      const toolCallDeltas: ToolCallDelta[] = Array.isArray(delta.tool_calls)
        ? delta.tool_calls.map((tc: any) => ({
            index: tc.index,
            id: tc.id,
            name: tc.function?.name ?? tc.name,
            argumentsDelta: tc.function?.arguments,
          }))
        : []
      const text = typeof delta.content === 'string' && delta.content.length ? delta.content : undefined
      // LlmChunk 单 toolCallDelta 口径：同事件多条 tool_calls 顺序展开为多 chunk
      if (!text && !toolCallDeltas.length && finish === undefined) {
        // 空事件但携 usage（部分 compat 网关形态）：usage 不随空事件丢失
        if (usage) yield { usage }
        continue
      }
      const chunks: LlmChunk[] = []
      if (toolCallDeltas.length === 0) {
        chunks.push({
          ...(text !== undefined ? { delta: text } : {}),
          ...(finish !== undefined
            ? { finishReason: finish, ...(finish === 'error' ? { error: { code: 'B080001', message: `未映射的 finish_reason "${raw}"` } } : {}) }
            : {}),
        })
      } else {
        for (let i = 0; i < toolCallDeltas.length; i++) {
          const last = i === toolCallDeltas.length - 1
          chunks.push({
            ...(i === 0 && text !== undefined ? { delta: text } : {}),
            toolCallDelta: toolCallDeltas[i],
            ...(last && finish !== undefined
              ? { finishReason: finish, ...(finish === 'error' ? { error: { code: 'B080001', message: `未映射的 finish_reason "${raw}"` } } : {}) }
              : {}),
          })
        }
      }
      // 1.11-S1（D-33）：usage 与事件内容同 chunk 到达（网关共存形态）→ 附着于本事件最后一个 chunk
      if (usage) chunks[chunks.length - 1]!.usage = usage
      for (const c of chunks) yield c
    }
  }
}

export function createOpenAICompatAdapter(opts: OpenAICompatOptions): LlmAdapter & { id: string } {
  const id = opts.id ?? 'openai-compat'
  const baseUrl = opts.baseUrl.replace(/\/+$/, '')
  // 1.4-S4（D-12a，1.2 规划期裁决）：TLS 门 1.5-S1 抽取共用（口径与报错文案不变）
  assertTlsOrLoopback(baseUrl)
  const url = `${baseUrl}/chat/completions`
  // 1.8-BUG-1：缺省 node:http(s)（undici 退出崩溃——面头注记）；注入缝保留
  const fetchImpl = opts.fetchImpl ?? nodeHttpSseFetch as unknown as typeof fetch
  const sleep = opts.sleep ?? (ms => new Promise<void>(r => setTimeout(r, ms)))
  const timeoutMs = opts.timeoutMs ?? 120_000
  const firstByteMs = opts.firstByteMs ?? 30_000
  const retries = opts.retries ?? 2
  const backoffMs = opts.backoffMs ?? [1_000, 2_000]
  // 1.14-S4（K-POOL-1）：成员级 keyEnv 精确候选——keyEnv 引用即显式意见（env 通道开启；候选=仅该变量，keychain 链保持在前）
  const credResolveOpts = opts.credentialEnvVars?.length
    ? { envVarCandidates: opts.credentialEnvVars, allowEnvFallback: true }
    : {}

  const toOpenAI = (req: LlmRequest, apiKey: string) => ({
    // 1.4-BUG-1：method: 'POST' 缺失——M8 最小实现潜伏缺陷（注入式 fetch 的单测忽略 method，
    // 真 undici 对 GET+body 直接拒绝）；car run 真路径接线时暴露（生产调用点核查产出）
    method: 'POST' as const,
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: req.model,
      stream: true,
      // 1.14-S1（K-MP-1 / D-39）：思考参数——effort 非 off/缺席才下发 reasoning_effort（off = 字节面零痕迹）
      ...(normalizeReasoningEffort(req.reasoning?.effort) !== undefined &&
        normalizeReasoningEffort(req.reasoning?.effort) !== 'off'
        ? { reasoning_effort: normalizeReasoningEffort(req.reasoning?.effort) }
        : {}),
      // 1.11-S1（D-33 / 计量设计 §9-2 推荐A）：usage 采集默认开启；第三方网关不兼容时的
      // 回退方案（baseUrl 白名单）登记可回退项——不支持网关走缺失口径（禁估算补造）
      stream_options: { include_usage: true },
      ...(req.maxTokens != null ? { max_tokens: req.maxTokens } : {}),
      messages: req.messages.map(m => {
        if (m.role === 'toolResult') {
          const p = m.content as { id?: string; result?: unknown; error?: string }
          return { role: 'tool', tool_call_id: p?.id, content: p?.error ?? JSON.stringify(p?.result ?? null) }
        }
        if (m.role === 'assistant' && m.content != null && typeof m.content === 'object' && 'toolCall' in (m.content as object)) {
          const tc = (m.content as { toolCall: { id: string; tool: string; args: unknown } }).toolCall
          return {
            role: 'assistant',
            content: null,
            tool_calls: [{ id: tc.id, type: 'function', function: { name: tc.tool, arguments: JSON.stringify(tc.args ?? {}) } }],
          }
        }
        return { role: m.role, content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }
      }),
      // declaredSideEffect 不出站：权限面只进权限门（§3.2.M8.3 字段表约束方向）
      ...(req.tools.length ? { tools: req.tools.map(t => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } })) } : {}),
    }),
  })

  return {
    id,
    chat(req: LlmRequest): AsyncIterable<LlmChunk> {
      return streamSsePost({
        url,
        // 凭据门：resolve → reveal（SQ-07 凭据解析；A080001 在此抛出——首块前，runTurn 可 error 收口）
        buildRequest: async () => {
          let apiKey = ''
          if (opts.credentials) {
            const ref = opts.credentials.resolve(opts.provider ?? id, credResolveOpts)
            apiKey = opts.credentials.reveal(ref, {})
          }
          return toOpenAI(req, apiKey)
        },
        fetchImpl,
        signal: req.signal,
        timeoutMs, firstByteMs, retries, backoffMs, sleep,
      }, (body) => parseSseStream(body, req.model, id))
    },
  }
}

// ==================== 内置 anthropic 适配器（Messages API 流式 SSE，1.5-S1 / D-20） ====================

export interface AnthropicAdapterOptions {
  id?: string
  /** API 源（如 https://api.anthropic.com；请求路径 = {baseUrl}/v1/messages，与官方 SDK base_url 同约定） */
  baseUrl: string
  /** 凭据服务与 provider 名（x-api-key 来源；provider 缺省 'anthropic' → ANTHROPIC_API_KEY） */
  credentials?: CredentialService
  provider?: string
  fetchImpl?: typeof fetch
  /** §3.5.4 基线：总 120s / 首字节 30s / 2 次退避 1s-2s（与 openai-compat 同款） */
  timeoutMs?: number
  firstByteMs?: number
  retries?: number
  backoffMs?: number[]
  sleep?: (ms: number) => Promise<void>
  /** D-20：Anthropic API max_tokens 必填——req.maxTokens 缺席时取此缺省（provider 差异登记，缺省 4096） */
  defaultMaxTokens?: number
  /** 1.14-S4（K-POOL-1）：成员级凭据 env 变量名引用（modelPool keyEnv——resolve 精确候选；keychain 链保持在前） */
  credentialEnvVars?: string[]
}

/** stop_reason → CAR finishReason（未映射 fail-visible——openai FINISH_MAP 同纪律） */
const ANTHROPIC_STOP_REASON_MAP: Record<string, LlmChunk['finishReason']> = {
  end_turn: 'stop',
  stop_sequence: 'stop',
  max_tokens: 'length',
  tool_use: 'toolUse',
  refusal: 'aborted',
}

/**
 * 1.11-S1（D-33 / 计量设计 §3.2）：anthropic usage 两包合并——message_start（input 侧：
 * input_tokens 天然不含 cache + cache_read/cache_creation）+ message_delta（output 侧：
 * output_tokens）。任一包缺席或主字段非数值 = 侧不完整，整条不落（缺失口径，禁补造半条事实）；
 * providerRaw 保留两原始片段供审计对拍。
 * 1.18.1-K6-A：网关形态兼容——商汤网关（装机会话实证 2026-10-25）把 input 侧三键放
 * message_delta（message_start.input_tokens 常为 0，真实 input/cache_read 在 delta），
 * 官方形态 delta 仅 output_tokens。判别式 = delta 是否携带任一 input 侧键；input 侧
 * 整体取自单一来源（不混取两包、不估算），D-51 thresholdTokens 事实源
 * （input+cacheRead+cacheCreation 之和）在两形态下同为 provider 报告的全上下文。
 */
function mergeAnthropicUsage(
  start: Record<string, unknown> | null,
  delta: Record<string, unknown> | null,
  model: string,
  adapterId: string,
): LlmUsage | undefined {
  if (!start || !delta) return undefined
  if (typeof delta.output_tokens !== 'number') return undefined
  const deltaHasInputSide =
    typeof delta.input_tokens === 'number' ||
    typeof delta.cache_read_input_tokens === 'number' ||
    typeof delta.cache_creation_input_tokens === 'number'
  const inputSrc = deltaHasInputSide ? delta : start
  if (typeof inputSrc.input_tokens !== 'number') return undefined
  // 1.14-S3（K-MP-2b / D-41）：anthropic 无输出细分事实（thinking 计入 output_tokens）→
  // segments 不带键（禁估算补造——桌面色条退化单色，登记口径）
  return {
    inputTokens: inputSrc.input_tokens,
    outputTokens: delta.output_tokens,
    cacheReadTokens: typeof inputSrc.cache_read_input_tokens === 'number' ? inputSrc.cache_read_input_tokens : 0,
    cacheCreationTokens: typeof inputSrc.cache_creation_input_tokens === 'number' ? inputSrc.cache_creation_input_tokens : 0,
    model,
    adapterId,
    providerRaw: { messageStart: start, messageDelta: delta },
  }
}

/**
 * Anthropic Messages API 请求体（D-20）：system 消息提升为顶层 `system`（多条 \n\n 连接）；
 * toolResult 收敛进 user 消息 content（连续多条合并为单 user 多 tool_result 块——Anthropic
 * 消息序列约束）；assistant 工具调用 = content:[{type:'tool_use',id,name,input}]；
 * declaredSideEffect 不出站（与 openai-compat 同红线）。
 * 1.17-K4（D-48 P1）：system 以单块数组出站并挂 `cache_control: ephemeral` 断点（稳定前缀
 * 缓存——首个 system 恒不进折叠区间，锚点天然稳定）。断点 = 传输层注解：不进 SessionLog/
 * 投影/快照比对，N1 零影响；生效有 provider 侧最小长度门槛（~1024 tokens）——短 system
 * 静默不生效应以 usage.cacheCreationTokens 观测，禁以「配了就该生效」推断。关断 =
 * CAR_LLM_PROMPT_CACHE=off（cli flag --no-prompt-cache 置本 env；A/B 与故障回退通道）。
 */
function promptCacheOff(): boolean {
  return process.env.CAR_LLM_PROMPT_CACHE === 'off'
}

function toAnthropic(req: LlmRequest, apiKey: string) {
  const system: string[] = []
  const turns: Array<{ role: 'user' | 'assistant'; content: unknown }> = []
  let pendingToolResults: Array<Record<string, unknown>> = []
  const flushToolResults = () => {
    if (!pendingToolResults.length) return
    turns.push({ role: 'user', content: pendingToolResults })
    pendingToolResults = []
  }
  for (const m of req.messages) {
    if (m.role === 'system') {
      system.push(typeof m.content === 'string' ? m.content : JSON.stringify(m.content))
      continue
    }
    if (m.role === 'toolResult') {
      const p = m.content as { id?: string; result?: unknown; error?: string }
      pendingToolResults.push({
        type: 'tool_result',
        tool_use_id: p?.id ?? '',
        content: p?.error ?? JSON.stringify(p?.result ?? null),
        ...(p?.error ? { is_error: true } : {}),
      })
      continue
    }
    flushToolResults()
    if (m.role === 'assistant' && m.content != null && typeof m.content === 'object' && 'toolCall' in (m.content as object)) {
      const tc = (m.content as { toolCall: { id: string; tool: string; args: unknown } }).toolCall
      turns.push({ role: 'assistant', content: [{ type: 'tool_use', id: tc.id, name: tc.tool, input: tc.args ?? {} }] })
    } else {
      turns.push({ role: m.role, content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) })
    }
  }
  flushToolResults()
  // 1.14-S1（K-MP-1 / D-39）：思考参数——effort → thinking.budget_tokens（ANTHROPIC_THINKING_BUDGET 表）；
  // off/缺席不下发；budget ≥ max_tokens 违反 Messages API 约束（max_tokens 必须大于 budget_tokens）→
  // 显式报错提示调高（fail-visible，禁静默改写 max_tokens）
  const reasoningEffort = normalizeReasoningEffort(req.reasoning?.effort)
  const thinkingBudget = reasoningEffort && reasoningEffort !== 'off' ? ANTHROPIC_THINKING_BUDGET[reasoningEffort] : undefined
  const maxTokens = req.maxTokens ?? 4096
  if (thinkingBudget !== undefined && thinkingBudget >= maxTokens) {
    throw new Error(`CAR-E-LLM-REASONING: thinking budget_tokens(${thinkingBudget}) 必须小于 max_tokens(${maxTokens})——请调高 maxTokens（禁静默改写请求参数）`)
  }
  return {
    method: 'POST' as const,
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: req.model,
      stream: true,
      max_tokens: maxTokens,
      ...(thinkingBudget !== undefined ? { thinking: { type: 'enabled', budget_tokens: thinkingBudget } } : {}),
      // D-48 P1：缺省单块 + ephemeral 断点；关断 = 顶层字符串（1.16.x 前形态，A/B 与回退）
      ...(system.length
        ? {
            system: promptCacheOff()
              ? system.join('\n\n')
              : [{ type: 'text', text: system.join('\n\n'), cache_control: { type: 'ephemeral' } }],
          }
        : {}),
      messages: turns,
      ...(req.tools.length
        ? { tools: req.tools.map(t => ({ name: t.name, description: t.description, input_schema: t.parameters })) }
        : {}),
    }),
  }
}

/**
 * Anthropic SSE → LlmChunk 流解析（data-only：data JSON 自带 `type` 字段，`event:` 行不依赖）。
 * content_block_start(tool_use) → toolCallDelta{id,name}；input_json_delta → toolCallDelta{argumentsDelta}；
 * message_delta.stop_reason → finishReason（终态信号，单次）；ping/message_stop/未知事件容错跳过。
 * 1.11-S1（D-33）：message_start.usage 采集 input 侧（原解析整体跳过该事件）+ message_delta.usage
 * 合并 output 侧附着于终态 chunk；流中断 delta 未到 = output 侧不完整，整条不落（R-2）。
 */
async function* parseAnthropicSseStream(body: AsyncIterable<Uint8Array>, model: string, adapterId: string): AsyncIterable<LlmChunk> {
  const decoder = new TextDecoder()
  let buf = ''
  let startUsage: Record<string, unknown> | null = null
  for await (const bytes of body) {
    buf += decoder.decode(bytes, { stream: true })
    let nl: number
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).replace(/\r$/, '')
      buf = buf.slice(nl + 1)
      if (!line.startsWith('data:')) continue
      const data = line.slice(5).trim()
      if (!data) continue
      let evt: any
      try { evt = JSON.parse(data) } catch { continue } // 心跳/注释行容错跳过
      const type = evt?.type
      if (type === 'content_block_start') {
        const block = evt.content_block
        if (block?.type === 'tool_use') {
          yield { toolCallDelta: { index: evt.index, id: block.id, name: block.name } }
        }
      } else if (type === 'content_block_delta') {
        const d = evt.delta
        if (d?.type === 'text_delta' && typeof d.text === 'string' && d.text.length) {
          yield { delta: d.text }
        } else if (d?.type === 'input_json_delta' && typeof d.partial_json === 'string' && d.partial_json.length) {
          yield { toolCallDelta: { index: evt.index, argumentsDelta: d.partial_json } }
        }
        // thinking_delta / citations_delta 等非 CAR 消费面：容错跳过
      } else if (type === 'message_start') {
        // 1.11-S1（D-33）：input 侧采集（usage 嵌套在 message 下）
        const u = (evt.message as Record<string, unknown> | undefined)?.usage
        if (u && typeof u === 'object') startUsage = u as Record<string, unknown>
      } else if (type === 'message_delta') {
        const raw = evt.delta?.stop_reason
        // 1.11-S1（D-33）：output 侧（delta.usage.output_tokens）与 input 侧合并——两包齐才落
        const usage = mergeAnthropicUsage(startUsage, (evt.usage ?? null) as Record<string, unknown> | null, model, adapterId)
        if (raw != null) {
          const finish = ANTHROPIC_STOP_REASON_MAP[String(raw)]
          const chunk: LlmChunk = finish
            ? { finishReason: finish }
            : { finishReason: 'error', error: { code: 'B080001', message: `未映射的 stop_reason "${raw}"` } }
          yield usage ? { ...chunk, usage } : chunk
        } else if (usage) {
          // delta 未携 stop_reason 但携 usage（网关形态）：usage 不随缺失终态信号丢失
          yield { usage }
        }
      } else if (type === 'error') {
        // 流内 error 事件（overloaded_error 等）→ error chunk 收口（后续 message_delta 由守卫拦冲突）
        yield { finishReason: 'error', error: { code: 'B080001', message: `provider 流错误：${evt.error?.message ?? JSON.stringify(evt).slice(0, 200)}` } }
      }
    }
  }
}

export function createAnthropicAdapter(opts: AnthropicAdapterOptions): LlmAdapter & { id: string } {
  const id = opts.id ?? 'anthropic'
  const baseUrl = opts.baseUrl.replace(/\/+$/, '')
  assertTlsOrLoopback(baseUrl)
  const url = `${baseUrl}/v1/messages`
  // 1.8-BUG-1：缺省 node:http(s)（undici 退出崩溃——面头注记）；注入缝保留
  const fetchImpl = opts.fetchImpl ?? nodeHttpSseFetch as unknown as typeof fetch
  const sleep = opts.sleep ?? (ms => new Promise<void>(r => setTimeout(r, ms)))
  const timeoutMs = opts.timeoutMs ?? 120_000
  const firstByteMs = opts.firstByteMs ?? 30_000
  const retries = opts.retries ?? 2
  const backoffMs = opts.backoffMs ?? [1_000, 2_000]
  // 1.14-S4（K-POOL-1）：成员级 keyEnv 精确候选（同 openai-compat 口径）
  const credResolveOpts = opts.credentialEnvVars?.length
    ? { envVarCandidates: opts.credentialEnvVars, allowEnvFallback: true }
    : {}

  return {
    id,
    chat(req: LlmRequest): AsyncIterable<LlmChunk> {
      return streamSsePost({
        url,
        // 凭据门：resolve → reveal（provider='anthropic' → keychain car-runtime/anthropic →
        // env ANTHROPIC_API_KEY——credentials.ts 1.4 既有登记；A080001 首块前抛出）
        buildRequest: async () => {
          let apiKey = ''
          if (opts.credentials) {
            const ref = opts.credentials.resolve(opts.provider ?? id, credResolveOpts)
            apiKey = opts.credentials.reveal(ref, {})
          }
          return toAnthropic(req, apiKey)
        },
        fetchImpl,
        signal: req.signal,
        timeoutMs, firstByteMs, retries, backoffMs, sleep,
      }, (body) => parseAnthropicSseStream(body, req.model, id))
    },
  }
}
