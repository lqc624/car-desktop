/**
 * M6 · car doctor 增强（《系统设计》§3.2.M6.2 引导行：环境自检——沙箱/凭据/连通性）
 *
 * 口径：
 *  - 凭据检查只探存在性、绝不打印值（secrets 红线：值入日志即泄露面）
 *  - 连通性检查网络不可达 = 显式 SKIPPED 而非 FAIL——测试环境必须可离线通过（不失败）
 *  - 1.1-S2：签名就绪检查行（mode / 信任根 / 配置文件通道发现态）——诊断面只读，
 *    门禁判定仍在 sigGate/verifier；公钥可打印、信任根值本身不打印
 */
import { createPublicKey } from 'node:crypto'
import { CredentialService, providerEnvVars } from '../runtime-core/credentials.ts'
import { loadCarConfig, mergeSignatureGate, mergeLlmConfig } from '../load/config.ts'

export interface CredentialCheck {
  name: string
  envVar: string
  present: boolean
  hint: string
}

/** 凭据存在性检查：只报 present/not-set，永不输出值 */
export function doctorCredentials(env: NodeJS.ProcessEnv = process.env): CredentialCheck[] {
  return [
    {
      name: 'CAR 凭据',
      envVar: 'CAR_TOKEN',
      present: !!env.CAR_TOKEN,
      hint: 'registry 发布/拉取鉴权用；未设置不影响本地插件开发',
    },
    {
      name: 'npm token',
      envVar: 'NPM_TOKEN',
      present: !!env.NPM_TOKEN,
      hint: 'npm publish 需要时请设置（export NPM_TOKEN=…），值不入日志',
    },
  ]
}

export interface ConnectivityResult {
  status: 'PASS' | 'SKIPPED'
  detail: string
  latencyMs: number
}

/** M8 增强：keychain 通道状态（模型凭据读取面，§3.2.M8.2 凭据行）——能力探测口径，缺席显式降级不静默；离线可过 */
export function doctorKeychain(opts: { platform?: NodeJS.Platform } = {}): { available: boolean; note: string } {
  return new CredentialService({ platform: opts.platform }).channelStatus
}

export interface SignatureCheck {
  /** 生效模式（flag > env > 配置 > 缺省 warn——DEC-1 ②；enforce 缺省翻转 2026-12-25 登记计划内变更） */
  mode: 'warn' | 'enforce'
  /** 信任根通道：absent=未配置（全部插件按 unsigned 处理）；valid=在场且可解析；invalid=在场但解析失败（enforce 下拒签风险） */
  trustRoot: 'absent' | 'valid' | 'invalid'
  /** 配置文件通道（1.1-S3）：absent=cwd 未发现；found=已发现且校验通过；invalid=发现但解析/校验失败（fail-visible） */
  configFile: 'absent' | 'found' | 'invalid'
  detail: string
}

/** 1.1-S2 签名就绪检查：mode 生效值 + 信任根在场可解析性 + car.config.json 发现态（离线可过；值不打印） */
export function doctorSignature(opts: { env?: NodeJS.ProcessEnv; cwd?: string; configPath?: string } = {}): SignatureCheck {
  const env = opts.env ?? process.env
  const cfg = loadCarConfig({ explicitPath: opts.configPath, cwd: opts.cwd })
  let trustRoot: SignatureCheck['trustRoot'] = 'absent'
  const raw = env.CAR_TRUST_ROOT || cfg.config.sandbox?.sigTrustRoot
  if (raw) {
    try {
      createPublicKey({ key: Buffer.from(raw, 'base64'), format: 'der', type: 'spki' })
      trustRoot = 'valid'
    } catch {
      trustRoot = 'invalid'
    }
  }
  // 生效模式含配置层（配置文件解析失败时按 env/缺省口径合并，invalid 态在 configFile 显式呈现）
  const { mode } = mergeSignatureGate(env, cfg.error ? {} : cfg.config)
  const configFile: SignatureCheck['configFile'] = cfg.error ? 'invalid' : cfg.path ? 'found' : 'absent'
  const parts = [
    `mode=${mode}${mode === 'warn' ? '（DEC-1 ② 缺省；2026-12-25 到期翻转）' : ''}`,
    trustRoot === 'absent'
      ? '信任根未配置（全部插件按 unsigned 处理；car plugin-sign keygen 产出 .pub 即信任根）'
      : trustRoot === 'valid'
        ? '信任根已配置（ed25519 spki 可解析，值不打印）'
        : '信任根已配置但不可解析（CAR-E-SIG 拒签风险——检查 CAR_TRUST_ROOT / sandbox.sig.trustRoot 是否为 spki base64）',
    configFile === 'absent'
      ? '配置文件未发现（car.config.json）'
      : configFile === 'found'
        ? `配置文件 ${cfg.path}（校验通过）`
        : `配置文件无效（${cfg.error}）`,
  ]
  return { mode, trustRoot, configFile, detail: parts.join('；') }
}

export interface ModelReadinessCheck {
  /** baseUrl + model 均在场 = true（可发起真实模型请求的最低配置面） */
  configured: boolean
  baseUrl: string
  model: string
  /** 凭据通道探测（存在性，值不打印）：keychain 命中 / env 命中（显式开启时）/ 全落空 */
  credential: 'keychain' | 'env' | 'not-found'
  /** env fallback 开关态（CAR_ALLOW_ENV_CREDENTIALS=1 或 llm.allowEnvFallback） */
  envFallback: 'on' | 'off'
  detail: string
}

/** 1.4-S3 模型就绪检查（D-16）：baseUrl/model 在场性 + 凭据通道存在性探测（离线可过；值不打印） */
export function doctorModelReadiness(opts: { env?: NodeJS.ProcessEnv; cwd?: string; configPath?: string } = {}): ModelReadinessCheck {
  const env = opts.env ?? process.env
  const cfg = loadCarConfig({ explicitPath: opts.configPath, cwd: opts.cwd })
  const { baseUrl, model, adapterId, allowEnvFallback } = mergeLlmConfig(env, cfg.error ? {} : cfg.config)
  // 1.5-S4（D-20 配套）：adapterId → 凭据 provider 感知（anthropic → ANTHROPIC_API_KEY；缺省 openai-compat）
  const provider = adapterId === 'anthropic' ? 'anthropic' : 'openai-compat'
  const envFallback: ModelReadinessCheck['envFallback'] = allowEnvFallback ? 'on' : 'off'
  let credential: ModelReadinessCheck['credential'] = 'not-found'
  if (allowEnvFallback) {
    // env fallback 显式开启：provider 候选变量存在性（providerEnvVars；只探存在不取值）
    if (providerEnvVars(provider).some(n => env[n])) credential = 'env'
  }
  if (credential === 'not-found') {
    // keychain 通道存在性（resolve 探测，A080001 全落空即 not-found；值不打印）
    try {
      const ref = new CredentialService().resolve(provider, { env, allowEnvFallback })
      credential = ref.source
    } catch { /* 全落空 = not-found（登记口径，非错误） */ }
  }
  const configured = !!baseUrl && !!model
  const parts = [
    configured ? `baseUrl=${baseUrl} model=${model}${adapterId ? ` adapter=${adapterId}` : ''}` : 'baseUrl/model 未配置（car run 真路径需 llm.* 配置或 CAR_LLM_BASE_URL/CAR_LLM_MODEL——见 car doctor / 配置指南）',
    credential === 'keychain' ? `凭据=keychain 命中（car-runtime/${provider}，值不打印）`
      : credential === 'env' ? '凭据=env 命中（显式开启 fallback，值不打印）'
      : '凭据未就绪（keychain 未命中且 env fallback 未开或变量缺席——A080001 会引导至此）',
    `envFallback=${envFallback}`,
  ]
  return { configured, baseUrl: baseUrl ?? '', model: model ?? '', credential, envFallback, detail: parts.join('；') }
}

/**
 * registry 连通性检查：可达 = PASS（含延迟）；不可达/显式跳过 = SKIPPED（不失败）。
 * 默认 registry 取 CAR_REGISTRY_URL，缺省 npmjs。
 */
export async function doctorConnectivity(opts: {
  registryUrl?: string
  timeoutMs?: number
  /** 测试注入跳过 */
  skip?: boolean
} = {}): Promise<ConnectivityResult> {
  const url = opts.registryUrl ?? process.env.CAR_REGISTRY_URL ?? 'https://registry.npmjs.org/-/ping'
  if (opts.skip || process.env.CAR_OFFLINE === '1') {
    return { status: 'SKIPPED', detail: `显式离线（CAR_OFFLINE=1 或测试注入）——跳过 ${url}`, latencyMs: 0 }
  }
  const t0 = Date.now()
  // 同 1.4-BUG-2：AbortSignal.timeout → 手动 controller（进程退出 libuv win32 断言预防）
  const controller = new AbortController()
  const abortTimer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 2000)
  try {
    await fetch(url, { signal: controller.signal })
    return { status: 'PASS', detail: url, latencyMs: Date.now() - t0 }
  } catch (e) {
    clearTimeout(abortTimer)
    return {
      status: 'SKIPPED',
      detail: `registry 不可达（${(e as Error).name}: ${(e as Error).message}）——离线环境显式跳过，不判失败`,
      latencyMs: Date.now() - t0,
    }
  } finally {
    clearTimeout(abortTimer)
  }
}
